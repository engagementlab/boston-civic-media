<p class="tf_nowidget"> <?php _e('The sidebar you added has no widgets.
    Please add some from the', 'tfuse'); ?><a href="<?php echo admin_url('widgets.php') ?>" target="_blank"><?php _e('Widgets Page', 'tfuse'); ?></a>
</p>