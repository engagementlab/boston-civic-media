<a href="#" id="slider_add_new_create" class="button"><?php print apply_filters('tf_ext_slider_add_new_create_text', __('Create Slider', 'tfuse')); ?></a> <a id="slider_add_new_cancel" href="#" class="button reset-button"><?php _e('Cancel', 'tfuse'); ?></a>
<form id="add_new_form" action="" method="post">
    <input type="hidden" name="slider_design"/>
    <input type="hidden" name="slider_type"/>
    <input type="hidden" name="slider_title"/>
</form>