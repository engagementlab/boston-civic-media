<?php

$cfg['categories'] = array(
    __('Text & Images','tfuse') => 1,
    __('Buttons & Lists','tfuse') => 2,
    __('Charts','tfuse') => 3,
   __('Columns','tfuse')  => 4,
    __('PrettyPhoto','tfuse') => 5,
    __('Media','tfuse') => 6,
   __('Tables & Boxes','tfuse') => 7,
    __('Tabs & Toggles','tfuse') => 8,
    __('Typography','tfuse')=> 9,
   __('Maps','tfuse')  => 10,
    __('Widgets','tfuse') => 11
);
