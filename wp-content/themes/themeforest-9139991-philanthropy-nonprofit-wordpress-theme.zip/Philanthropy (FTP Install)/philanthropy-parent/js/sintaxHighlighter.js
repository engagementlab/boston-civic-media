SyntaxHighlighter.defaults['gutter'] = false;
			SyntaxHighlighter.defaults['toolbar'] = true;
			SyntaxHighlighter.all();