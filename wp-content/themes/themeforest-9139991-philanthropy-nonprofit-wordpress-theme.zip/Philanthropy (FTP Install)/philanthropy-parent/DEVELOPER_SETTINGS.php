<?php

//Below is the custom theme name you would like to set
//$theme_display_name = 'Philanthropy';

//Below are the variables that can disable specific parts of the framework. Set TRUE or FALSE
$disable_news_and_promo = TRUE;
//$disable_support = FALSE;
//$disable_export = FALSE;
//$disable_import = FALSE;
//$disable_updates = FALSE;
//$disable_megamenu = FALSE;

